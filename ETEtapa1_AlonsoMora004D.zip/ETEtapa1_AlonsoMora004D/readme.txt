ADMIN DJANGO

usuario: lonso
contraseña: admin1234

oracle

c##periodistas
contraseña: 1234

-- ejecutar api rest -- 

http://127.0.0.1:8000/lista_usuarios



