from django import forms
from django.forms import ModelForm,widgets 
from .models import Usuario , Pais
from django.forms.models import ModelChoiceField
from django.forms.widgets import Widget


class UsuarioForm(ModelForm):
    class Meta:
        model = Usuario
        fields = ['rut','foto', 'nombre', 'telefono', 'direccion','email','contraseña','pais']

    
        labels={
            'rut': 'Rut ',
            'foto': 'Foto',
            'nombre': 'Nombre ',
            'telefono': 'Telefono ',
            'direccion': 'Direccion',
            'email': 'Email',
            'contraseña': 'Contraseña',
            'pais': 'Pais ',

        }
        widgets={
            'rut': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'rut', 
                    'name': 'rut',
                    'placeholder': 'Digite rut'
                }
            ),
            'foto': forms.ClearableFileInput(
                attrs={
                    'class': 'form-control',
                    'id': 'foto'
                    ,'name': 'foto',
                    'accept':"foto/*"
                }
            ),
            'nombre': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'nombre', 
                    'placeholder': 'Ingrese nombre'

                }
            ), 
            'telefono': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'telefono', 
                    'placeholder': 'Ingrese telefono'

                }
            ),
            'direccion': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'direccion', 
                    'placeholder': 'Ingrese direccion'

                }
            ),
            'email': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'email', 
                    'placeholder': 'Ingrese email'

                }
            ),
            'contraseña': forms.TextInput(
                attrs={
                    'class': 'form-control',
                    'id': 'contraseña', 
                    'placeholder': 'Ingrese contraseña'

                }
            ),
    
            'pais': forms.Select(
                attrs={
                    'class': 'form-control',
                    'id': 'pais'
                }
            )
        }



