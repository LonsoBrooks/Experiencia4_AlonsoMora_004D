from django.urls import path
from .views import Inicio , lista_api, form_usuario ,Ver,form_mod_usuario, form_del_usuario , lista_usuarios


urlpatterns =[

    path('', Inicio, name='Inicio'),
    path('lista_api', lista_api, name="lista_api"),
    path('form_crearusuario', form_usuario, name="form_crearusuario"),
    path('ver', Ver, name="ver"),
    path('form_mod_usuario/<id>', form_mod_usuario, name="form_mod_usuario"),
    path('form_del_usuario/<id>', form_del_usuario, name="form_del_usuario"),
    path('lista_usuarios', lista_usuarios, name="lista_usuarios") 

]