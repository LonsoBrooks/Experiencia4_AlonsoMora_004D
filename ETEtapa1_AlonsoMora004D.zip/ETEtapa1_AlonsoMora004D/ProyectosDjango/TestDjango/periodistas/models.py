from django.db import models
from django.db.models.deletion import CASCADE
from django.utils.timezone import timezone 

# Create your models here.

class Pais(models.Model):

    idPais = models.IntegerField(primary_key=True, verbose_name='Id Pais')
    nombrePais = models.CharField(max_length=50, default='nombre', verbose_name='Nombre Pais')



    def __str__(self):

        return (self.nombrePais)

class Usuario(models.Model):

    rut = models.CharField(max_length=10, primary_key=True, verbose_name='Rut colaborador')
    foto = models.ImageField(upload_to='usuarios/', null=True ,blank=True )
    nombre = models.CharField(max_length=20,  verbose_name='Nombre Completo')
    telefono = models.IntegerField( verbose_name='Telefono')
    direccion = models.CharField(max_length=20, verbose_name='Direccion')
    email = models.CharField(max_length=30, verbose_name='Email')
    contraseña = models.CharField(max_length=100 , verbose_name='Contraseña')
    pais = models.ForeignKey(Pais, on_delete=models.SET_NULL, null=True, blank=False)


    def __str__(self):

        return (self.rut)


